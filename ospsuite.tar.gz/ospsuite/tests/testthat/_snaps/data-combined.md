# dataType can be changed after dataset is added

    Code
      myDC$setDataTypes(names = c("Observed", "Simulated"), dataTypes = c("observed",
        "simulated"))

