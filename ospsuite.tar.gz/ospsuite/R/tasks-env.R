# Environment that holds .Net tasks initiated by ospsuite,
# It is not exported and should not be directly manipulated by other packages.
tasksEnv <- new.env(parent = emptyenv())
